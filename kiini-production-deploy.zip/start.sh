#!/bin/bash
set -e
# Kiini Production Startup Script
# Environment variables are provided by the host/cPanel runtime.

echo "Starting Kiini: One Hub. Total Control..."

# Set production environment
export NODE_ENV=production

# app.js loads the environment, runs migrations, then starts the server.
exec node app.js
